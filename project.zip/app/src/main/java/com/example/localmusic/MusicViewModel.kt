package com.example.localmusic

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.localmusic.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class MusicViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    val songs = MutableStateFlow<List<Song>>(emptyList())
    val loading = MutableStateFlow(false)
    val currentId = MutableStateFlow<Long?>(null)
    val isPlaying = MutableStateFlow(false)
    val position = MutableStateFlow(0L)
    val duration = MutableStateFlow(0L)
    val shuffle = MutableStateFlow(false)
    val repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val volume = MutableStateFlow(currentVolume())

    val playlists = dao.playlists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playlistSongs = dao.playlistSongs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val topPlayed = dao.topPlayed().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var controller: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) { isPlaying.value = playing }
        override fun onShuffleModeEnabledChanged(enabled: Boolean) { shuffle.value = enabled }
        override fun onRepeatModeChanged(mode: Int) { repeat.value = mode }
        override fun onPlaybackStateChanged(state: Int) { syncTime() }
        override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
            val id = item?.mediaId?.toLongOrNull()
            currentId.value = id
            position.value = 0
            syncTime()
            if (id != null) viewModelScope.launch { dao.initCount(id); dao.incCount(id) }
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                currentId.value = c.currentMediaItem?.mediaId?.toLongOrNull()
                isPlaying.value = c.isPlaying
                shuffle.value = c.shuffleModeEnabled
                repeat.value = c.repeatMode
                syncTime()
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                if (isPlaying.value) { controller?.let { position.value = it.currentPosition }; syncTime() }
                delay(500)
            }
        }
    }

    private fun syncTime() {
        controller?.let { c -> c.duration.takeIf { it > 0 }?.let { duration.value = it } ; position.value = c.currentPosition }
    }

    private fun currentVolume(): Float =
        audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

    fun scan() {
        if (loading.value) return
        viewModelScope.launch {
            loading.value = true
            songs.value = withContext(Dispatchers.IO) { MusicRepository.scan(app) }
            loading.value = false
        }
    }

    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.setMediaItems(list.map { it.toMediaItem() }, index.coerceIn(0, list.lastIndex), 0L)
        c.prepare(); c.play()
    }

    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() {
        controller?.let { if (it.currentPosition > 3000) it.seekTo(0) else it.seekToPreviousMediaItem() }
    }
    fun seekTo(ms: Long) { controller?.seekTo(ms); position.value = ms }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun setVolume(v: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (v * max).toInt().coerceIn(0, max), 0)
        volume.value = v
    }

    fun createPlaylist(name: String) { if (name.isNotBlank()) viewModelScope.launch { dao.insertPlaylist(PlaylistEntity(name = name.trim())) } }
    fun deletePlaylist(id: Long) { viewModelScope.launch { dao.deletePlaylist(id) } }
    fun addToPlaylist(pid: Long, sid: Long) { viewModelScope.launch { dao.addSong(PlaylistSongEntity(pid, sid)) } }
    fun removeFromPlaylist(pid: Long, sid: Long) { viewModelScope.launch { dao.removeSong(pid, sid) } }

    override fun onCleared() { controller?.removeListener(listener); controller?.release(); super.onCleared() }
}
