package com.example.localmusic.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class Song(
    val id: Long, val title: String, val artist: String, val album: String,
    val albumId: Long, val duration: Long, val dateAdded: Long, val uri: Uri
) {
    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album)
                .setArtworkUri(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId))
                .build()
        ).build()
}

object MusicRepository {
    private val exts = setOf("mp3", "wav", "flac", "m4a")

    fun scan(ctx: Context): List<Song> {
        val out = ArrayList<Song>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.DISPLAY_NAME
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 0",
                null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    try {
                        val name = c.getString(7) ?: ""
                        if (name.substringAfterLast('.', "").lowercase() !in exts) continue
                        val id = c.getLong(0)
                        val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "فنان غير معروف"
                        val album = c.getString(3)?.takeIf { it != "<unknown>" } ?: "ألبوم غير معروف"
                        out += Song(
                            id, c.getString(1) ?: name.substringBeforeLast('.'), artist, album,
                            c.getLong(4), c.getLong(5), c.getLong(6),
                            ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                        )
                    } catch (_: Exception) { /* skip corrupt row */ }
                }
            }
        } catch (_: Exception) { }
        return out
    }
}

@Entity data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(
    primaryKeys = ["playlistId", "songId"],
    foreignKeys = [ForeignKey(PlaylistEntity::class, ["id"], ["playlistId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("playlistId")]
)
data class PlaylistSongEntity(val playlistId: Long, val songId: Long, val addedAt: Long = System.currentTimeMillis())

@Entity data class PlayCountEntity(@PrimaryKey val songId: Long, val count: Int)

@Dao
interface MusicDao {
    @Query("SELECT * FROM PlaylistEntity ORDER BY name") fun playlists(): Flow<List<PlaylistEntity>>
    @Query("SELECT * FROM PlaylistSongEntity ORDER BY addedAt") fun playlistSongs(): Flow<List<PlaylistSongEntity>>
    @Query("SELECT * FROM PlayCountEntity ORDER BY count DESC LIMIT 30") fun topPlayed(): Flow<List<PlayCountEntity>>
    @Insert suspend fun insertPlaylist(p: PlaylistEntity): Long
    @Query("DELETE FROM PlaylistEntity WHERE id = :id") suspend fun deletePlaylist(id: Long)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addSong(ps: PlaylistSongEntity)
    @Query("DELETE FROM PlaylistSongEntity WHERE playlistId = :p AND songId = :s") suspend fun removeSong(p: Long, s: Long)
    @Query("INSERT OR IGNORE INTO PlayCountEntity(songId, count) VALUES(:id, 0)") suspend fun initCount(id: Long)
    @Query("UPDATE PlayCountEntity SET count = count + 1 WHERE songId = :id") suspend fun incCount(id: Long)
}

@Database(entities = [PlaylistEntity::class, PlaylistSongEntity::class, PlayCountEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): MusicDao
    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "music.db").build().also { inst = it }
        }
    }
}
