package com.example.localmusic.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val scheme = darkColorScheme(
    primary = Color(0xFF7FD1AE), onPrimary = Color(0xFF00391F),
    background = Color(0xFF0F1115), onBackground = Color(0xFFE4E6EA),
    surface = Color(0xFF171A20), onSurface = Color(0xFFE4E6EA),
    surfaceVariant = Color(0xFF232830), onSurfaceVariant = Color(0xFFA9AFBA)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme) { Surface(color = MaterialTheme.colorScheme.background, content = content) }
}
