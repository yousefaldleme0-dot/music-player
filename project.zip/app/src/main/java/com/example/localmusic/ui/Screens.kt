package com.example.localmusic.ui

import android.graphics.Bitmap
import android.net.Uri
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.localmusic.MusicViewModel
import com.example.localmusic.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun Artwork(uri: Uri?, modifier: Modifier = Modifier, px: Int = 256) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = if (uri == null) null else withContext(Dispatchers.IO) {
            runCatching { ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()
        }
    }
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.MusicNote, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SongRow(song: Song, current: Boolean, onClick: () -> Unit, onMore: (() -> Unit)? = null, trailing: @Composable (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(song.uri, Modifier.size(48.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            Text("${song.artist} • ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(fmt(song.duration), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (onMore != null) IconButton(onClick = onMore) { Icon(Icons.Filled.PlaylistAdd, "إضافة إلى قائمة") }
        trailing?.invoke()
    }
}

@Composable
fun MainScreen(vm: MusicViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    var addTarget by remember { mutableStateOf<Song?>(null) }
    val songs by vm.songs.collectAsState()
    val currentId by vm.currentId.collectAsState()
    val current = songs.find { it.id == currentId }

    Scaffold(bottomBar = {
        Column {
            if (current != null) MiniPlayer(vm, current) { showPlayer = true }
            NavigationBar {
                listOf("الرئيسية" to Icons.Filled.Home, "المكتبة" to Icons.Filled.LibraryMusic, "القوائم" to Icons.Filled.QueueMusic)
                    .forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(tab == i, { tab = i }, { Icon(icon, label) }, label = { Text(label) })
                    }
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm) { addTarget = it }
                1 -> LibraryScreen(vm) { addTarget = it }
                else -> PlaylistsScreen(vm)
            }
        }
    }
    if (showPlayer && current != null) {
        BackHandler { showPlayer = false }
        NowPlayingScreen(vm, current) { showPlayer = false }
    }
    addTarget?.let { s ->
        val playlists by vm.playlists.collectAsState()
        AlertDialog(onDismissRequest = { addTarget = null }, confirmButton = {},
            dismissButton = { TextButton({ addTarget = null }) { Text("إلغاء") } },
            title = { Text("إضافة إلى قائمة") },
            text = {
                if (playlists.isEmpty()) Text("لا توجد قوائم بعد. أنشئ قائمة من تبويب القوائم.")
                else LazyColumn { items(playlists) { p ->
                    Text(p.name, Modifier.fillMaxWidth().clickable { vm.addToPlaylist(p.id, s.id); addTarget = null }.padding(12.dp))
                } }
            })
    }
}

@Composable
fun MiniPlayer(vm: MusicViewModel, song: Song, onOpen: () -> Unit) {
    val playing by vm.isPlaying.collectAsState()
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onOpen).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Artwork(song.uri, Modifier.size(44.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, maxLines = 1, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton({ vm.previous() }) { Icon(Icons.Filled.SkipPrevious, "السابقة") }
        IconButton({ vm.togglePlay() }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "تشغيل/إيقاف") }
        IconButton({ vm.next() }) { Icon(Icons.Filled.SkipNext, "التالية") }
    }
}

@Composable
fun HomeScreen(vm: MusicViewModel, onAdd: (Song) -> Unit) {
    val songs by vm.songs.collectAsState()
    val top by vm.topPlayed.collectAsState()
    val currentId by vm.currentId.collectAsState()
    val recent = remember(songs) { songs.sortedByDescending { it.dateAdded }.take(20) }
    val byId = remember(songs) { songs.associateBy { it.id } }
    val most = remember(top, songs) { top.filter { it.count > 0 }.mapNotNull { byId[it.songId] }.take(15) }

    LazyColumn(Modifier.fillMaxSize()) {
        item { Text("الرئيسية", fontSize = 26.sp, modifier = Modifier.padding(16.dp)) }
        item { Text("أضيفت مؤخراً", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.primary) }
        item {
            if (recent.isEmpty()) Text("لا توجد أغانٍ بعد.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyRow(contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                itemsIndexed(recent) { i, s ->
                    Column(Modifier.width(120.dp).clickable { vm.play(recent, i) }) {
                        Artwork(s.uri, Modifier.size(120.dp), 400)
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item { Text("الأكثر استماعاً", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.primary) }
        if (most.isEmpty()) item { Text("ابدأ بتشغيل بعض الأغاني وستظهر هنا.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        itemsIndexed(most) { i, s -> SongRow(s, s.id == currentId, { vm.play(most, i) }, { onAdd(s) }) }
    }
}

@Composable
fun LibraryScreen(vm: MusicViewModel, onAdd: (Song) -> Unit) {
    val songs by vm.songs.collectAsState()
    val loading by vm.loading.collectAsState()
    val currentId by vm.currentId.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    val sorted = remember(songs) { songs.sortedBy { it.title.lowercase() } }
    val shown = remember(sorted, query) {
        if (query.isBlank()) sorted else sorted.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true,
                placeholder = { Text("ابحث عن أغنية أو فنان") }, leadingIcon = { Icon(Icons.Filled.Search, null) })
            IconButton({ vm.scan() }) { Icon(Icons.Filled.Refresh, "تحديث المكتبة") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (shown.isEmpty() && !loading) Text("لا توجد أغانٍ.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(shown, key = { _, s -> s.id }) { i, s -> SongRow(s, s.id == currentId, { vm.play(shown, i) }, { onAdd(s) }) }
        }
    }
}

@Composable
fun PlaylistsScreen(vm: MusicViewModel) {
    val playlists by vm.playlists.collectAsState()
    val links by vm.playlistSongs.collectAsState()
    val songs by vm.songs.collectAsState()
    val currentId by vm.currentId.collectAsState()
    var open by rememberSaveable { mutableStateOf<Long?>(null) }
    var creating by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    val byId = remember(songs) { songs.associateBy { it.id } }
    val pl = playlists.find { it.id == open }

    if (pl != null) {
        BackHandler { open = null }
        val list = links.filter { it.playlistId == pl.id }.mapNotNull { byId[it.songId] }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ open = null }) { Icon(Icons.Filled.ArrowBack, "رجوع") }
                Text(pl.name, fontSize = 22.sp, modifier = Modifier.weight(1f))
                IconButton({ if (list.isNotEmpty()) vm.play(list, 0) }) { Icon(Icons.Filled.PlayCircle, "تشغيل الكل") }
                IconButton({ vm.deletePlaylist(pl.id); open = null }) { Icon(Icons.Filled.Delete, "حذف القائمة") }
            }
            if (list.isEmpty()) Text("القائمة فارغة. أضف أغاني من المكتبة بزر +.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn { itemsIndexed(list) { i, s ->
                SongRow(s, s.id == currentId, { vm.play(list, i) }, null) {
                    IconButton({ vm.removeFromPlaylist(pl.id, s.id) }) { Icon(Icons.Filled.RemoveCircleOutline, "إزالة") }
                }
            } }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("قوائم التشغيل", fontSize = 26.sp, modifier = Modifier.weight(1f))
                FilledTonalButton({ creating = true }) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text("جديدة") }
            }
            if (playlists.isEmpty()) Text("لم تنشئ أي قائمة بعد.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn { items(playlists, key = { it.id }) { p ->
                val n = links.count { it.playlistId == p.id }
                ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text("$n أغنية") },
                    leadingContent = { Icon(Icons.Filled.QueueMusic, null) },
                    modifier = Modifier.clickable { open = p.id })
            } }
        }
    }
    if (creating) AlertDialog(onDismissRequest = { creating = false },
        title = { Text("قائمة جديدة") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("اسم القائمة") }) },
        confirmButton = { TextButton({ vm.createPlaylist(name); name = ""; creating = false }) { Text("إنشاء") } },
        dismissButton = { TextButton({ creating = false }) { Text("إلغاء") } })
}

@Composable
fun NowPlayingScreen(vm: MusicViewModel, song: Song, onClose: () -> Unit) {
    val playing by vm.isPlaying.collectAsState()
    val pos by vm.position.collectAsState()
    val dur by vm.duration.collectAsState()
    val shuffle by vm.shuffle.collectAsState()
    val repeat by vm.repeat.collectAsState()
    val volume by vm.volume.collectAsState()
    var dragging by remember { mutableStateOf<Float?>(null) }
    val total = (if (dur > 0) dur else song.duration).coerceAtLeast(1)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "إغلاق") } }
        Spacer(Modifier.height(8.dp))
        Artwork(song.uri, Modifier.fillMaxWidth().aspectRatio(1f), 800)
        Spacer(Modifier.height(24.dp))
        Text(song.title, fontSize = 22.sp, maxLines = 2, textAlign = TextAlign.Center)
        Text(song.artist, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Spacer(Modifier.height(16.dp))
        Slider(value = dragging ?: (pos.toFloat() / total), onValueChange = { dragging = it },
            onValueChangeFinished = { dragging?.let { vm.seekTo((it * total).toLong()) }; dragging = null })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(dragging?.let { (it * total).toLong() } ?: pos), fontSize = 12.sp)
            Text(fmt(total), fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.toggleShuffle() }) {
                Icon(Icons.Filled.Shuffle, "عشوائي", tint = if (shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton({ vm.previous() }, Modifier.size(56.dp)) { Icon(Icons.Filled.SkipPrevious, "السابقة", Modifier.size(36.dp)) }
            FilledIconButton({ vm.togglePlay() }, Modifier.size(72.dp)) {
                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "تشغيل/إيقاف", Modifier.size(40.dp))
            }
            IconButton({ vm.next() }, Modifier.size(56.dp)) { Icon(Icons.Filled.SkipNext, "التالية", Modifier.size(36.dp)) }
            IconButton({ vm.cycleRepeat() }) {
                Icon(if (repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "تكرار",
                    tint = if (repeat != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.VolumeUp, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(volume, { vm.setVolume(it) }, Modifier.weight(1f))
        }
    }
}
