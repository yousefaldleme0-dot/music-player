1) Open this folder in Android Studio (Koala or newer) with JDK 17. Let Gradle sync.
2) Build > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
   or from terminal: ./gradlew assembleDebug  (Studio generates the wrapper jar)
3) Enable USB debugging and press Run, or copy the APK to the phone and install it.
